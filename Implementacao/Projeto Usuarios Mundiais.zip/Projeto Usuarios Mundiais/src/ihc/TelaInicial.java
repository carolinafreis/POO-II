package ihc;

import principal.PercentualPaises;
import principal.Pais;
import java.awt.event.ActionEvent;
import java.util.List;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.ScatterChart;
import javafx.scene.chart.XYChart;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTable;

public class TelaInicial extends javax.swing.JFrame {

    private PercentualPaises porcentagem;

    public TelaInicial(PercentualPaises porcentagem) {
        initComponents();
        this.porcentagem = porcentagem;
        inicializarComboBoxAno();
        inicializarSliderPorcentagem();
    }

    private void inicializarComboBox() {
        List<String> anos = porcentagem.periodo;
        DefaultComboBoxModel model = new DefaultComboBoxModel(anos.toArray(new String[anos.size()]));
        this.cmbBoxAnos.setModel(model);
    }

    private void inicializarComboBoxAno() {
        List<String> anos = porcentagem.periodo;
        this.cmbBoxAnos.addItem(" ");
        for (String nome : anos) {
            this.cmbBoxAnos.addItem(nome);
        }
    }

    //Definição da Porcentagem
    private void inicializarSliderPorcentagem() {
        sliderPorcentagem.setMinimum(0);
        sliderPorcentagem.setMaximum(100);
        sliderPorcentagem.setMajorTickSpacing(10);
        sliderPorcentagem.setMinorTickSpacing(5);
        sliderPorcentagem.setPaintTicks(true);
        sliderPorcentagem.setPaintLabels(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        lblTitulo = new javax.swing.JLabel();
        btnConsulta = new javax.swing.JButton();
        btnTeste = new javax.swing.JButton();
        btnGraficar = new javax.swing.JButton();
        sliderPorcentagem = new javax.swing.JSlider();
        cmbBoxAnos = new javax.swing.JComboBox<>();
        txtNome = new javax.swing.JTextField();
        lblNome = new javax.swing.JLabel();
        lblAnos = new javax.swing.JLabel();
        lblPercentual = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblResultado = new javax.swing.JTable();
        txtIdPais = new javax.swing.JTextField();
        lblIdPais = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblTitulo.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        lblTitulo.setText("     Percentual mundial de usuários da internet (2000 – 2015)");

        btnConsulta.setText("Pesquisar");
        btnConsulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultaActionPerformed(evt);
            }
        });

        btnTeste.setText("Histórico Completo");
        btnTeste.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTesteActionPerformed(evt);
            }
        });

        btnGraficar.setText("Gerar Gráfico");
        btnGraficar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGraficarActionPerformed(evt);
            }
        });

        cmbBoxAnos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbBoxAnosActionPerformed(evt);
            }
        });

        txtNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeActionPerformed(evt);
            }
        });

        lblNome.setText("Pesquisa por Nome País :");

        lblAnos.setText("Ano Específico :");

        lblPercentual.setText("Percentual Menor/Igual :");

        tblResultado.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane3.setViewportView(tblResultado);

        txtIdPais.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdPaisActionPerformed(evt);
            }
        });

        lblIdPais.setText("Pesquisa por Id do País :");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblNome)
                            .addComponent(lblAnos)
                            .addComponent(lblPercentual))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(368, 368, 368)
                                .addComponent(lblIdPais)
                                .addGap(18, 18, 18)
                                .addComponent(txtIdPais, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(cmbBoxAnos, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(77, 77, 77)
                                .addComponent(btnConsulta))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(sliderPorcentagem, javax.swing.GroupLayout.PREFERRED_SIZE, 442, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(97, 97, 97)
                                .addComponent(btnTeste)
                                .addGap(66, 66, 66)
                                .addComponent(btnGraficar))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(276, 276, 276)
                        .addComponent(lblTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 407, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 903, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(lblTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNome)
                    .addComponent(txtIdPais, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblIdPais))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbBoxAnos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAnos))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(sliderPorcentagem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblPercentual)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnTeste)
                            .addComponent(btnGraficar))))
                .addGap(31, 31, 31)
                .addComponent(btnConsulta)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(39, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnTesteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTesteActionPerformed
        String id = this.txtIdPais.getText().trim();
        Pais pais = this.porcentagem.selecionarPais(id);
        System.out.println(pais);
        if (pais != null) {
            this.tblResultado.setModel(new Tabela(this.porcentagem, pais));
        } else {
        }
    }//GEN-LAST:event_btnTesteActionPerformed

    private void btnGraficarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGraficarActionPerformed
        if ((this.txtIdPais.getText().trim()).equals("")) {
            return;
        }
        Pais pais = this.porcentagem.selecionarPais(this.txtIdPais.getText().trim());
        JDialog janPl = new JDialog();
        JFXPanel fxPanel = new JFXPanel();
        janPl.add(fxPanel);
        janPl.setSize(800, 600);
        janPl.setVisible(true);
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                initFX(fxPanel, pais);
            }
        });
    }//GEN-LAST:event_btnGraficarActionPerformed

    private void cmbBoxAnosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbBoxAnosActionPerformed
    }//GEN-LAST:event_cmbBoxAnosActionPerformed

    private void btnConsultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultaActionPerformed
        this.tblResultado.setModel(new Tabela(this.porcentagem,
                this.porcentagem.consultarPaises(this.txtNome.getText().trim().toLowerCase()),
                this.cmbBoxAnos.getSelectedItem().toString(),
                this.sliderPorcentagem.getValue())
        );
    }//GEN-LAST:event_btnConsultaActionPerformed

    private void txtNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeActionPerformed
    }//GEN-LAST:event_txtNomeActionPerformed

    private void txtIdPaisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdPaisActionPerformed
    }//GEN-LAST:event_txtIdPaisActionPerformed

    private void initFX(JFXPanel panel, Pais pais) {
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Anos");
        yAxis.setLabel("Percentual");
        final BarChart<String, Number> bc = new BarChart<>(xAxis, yAxis);

        bc.setTitle("País / Território : " + pais.getNome());
        XYChart.Series series1 = new XYChart.Series();
        series1.setName("Porcentagem");

        for (String ano : this.porcentagem.periodo) {
            series1.getData().add(new XYChart.Data(ano, pais.consultarDado(ano)));
        }

        bc.getData().addAll(series1);
        Scene scene = new Scene(bc, 800, 600);
        panel.setScene(scene);
    }

    public static void main(String args[]) {

        PercentualPaises percentualMundo = new PercentualPaises();

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaInicial(percentualMundo).setVisible(true);
            }
        });

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnConsulta;
    private javax.swing.JButton btnGraficar;
    private javax.swing.JButton btnTeste;
    private javax.swing.JComboBox<String> cmbBoxAnos;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lblAnos;
    private javax.swing.JLabel lblIdPais;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblPercentual;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JSlider sliderPorcentagem;
    private javax.swing.JTable tblResultado;
    private javax.swing.JTextField txtIdPais;
    private javax.swing.JTextField txtNome;
    // End of variables declaration//GEN-END:variables
}
