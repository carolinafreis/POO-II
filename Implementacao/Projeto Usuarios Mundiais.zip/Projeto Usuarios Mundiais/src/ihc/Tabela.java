package ihc;

import principal.Pais;
import principal.PercentualPaises;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import javax.swing.table.AbstractTableModel;

public class Tabela extends AbstractTableModel {

    Map<String, Pais> qtdPaises;
    PercentualPaises tblResultado;
    private int max = 100;
    private final String[] pos;
    private final String[] identificadores;

    public Tabela(PercentualPaises porcentagem, Pais pais) {
        /*
         * Manipulaçao de dados do arquivo csv na tabela
         */
        this.tblResultado = porcentagem;
        int i = 2;
        int quantidade = tblResultado.periodo.size() + 2;
        pos = new String[quantidade];
        pos[0] = "ID";
        pos[1] = "NOME";
        for (String ano : this.tblResultado.periodo) {
            pos[i] = ano;
            i++;
        }
        this.qtdPaises = new TreeMap<>();
        qtdPaises.put(pais.getId(), pais);
        identificadores = qtdPaises.keySet().toArray(new String[qtdPaises.size()]);
    }

    public Tabela(PercentualPaises todos, Map<String, Pais> qtdPaises, String faixa, int porcent) {
        int quantidade;
        this.tblResultado = todos;
        this.max = porcent;
        /* 
         * Listagem dos anos: vários ou um único
         */
        if (faixa.equals(" ")) {
            quantidade = tblResultado.periodo.size() + 2;
            pos = new String[quantidade];
            pos[0] = "ID";
            pos[1] = "NOME";
            int i = 2;
            for (String ano : this.tblResultado.periodo) {
                pos[i] = ano;
                i++;
            }
        } else {
            quantidade = 3;
            pos = new String[quantidade];
            pos[0] = "ID";
            pos[1] = "NOME";
            pos[2] = faixa;
        }
        this.qtdPaises = qtdPaises;
        identificadores = qtdPaises.keySet().toArray(new String[qtdPaises.size()]);
    }

    @Override
    public int getRowCount() {
        return this.identificadores.length;
    }

    @Override
    public int getColumnCount() {
        return pos.length;
    }

    @Override
    public String getColumnName(int num) {
        return this.pos[num];
    }

    @Override
    public Object getValueAt(int indiceL, int indiceC) {
        String keyId = this.identificadores[indiceL];
        switch (indiceC) {
            case 0:
                return this.qtdPaises.get(keyId).getId();
            case 1:
                return this.qtdPaises.get(keyId).getNome();
        }
        String ano = this.pos[indiceC];
        double percentual = this.qtdPaises.get(keyId).consultarDado(ano);
        if (this.max >= percentual) {
            return percentual;
        } else {
            return null;
        }
    }
}
