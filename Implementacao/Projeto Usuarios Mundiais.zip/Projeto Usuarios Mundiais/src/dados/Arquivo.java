package dados;

import principal.Pais;
import com.opencsv.CSVReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Arquivo {

    List<String> anos = new ArrayList();

    public Map<String, Pais> lerArquivoCSV() {
        Map<String, Pais> qtdPaises = new TreeMap();
        try {
            boolean primeiraLinha = false;
            String[] proximo;
            CSVReader reader = new CSVReader(new FileReader("csv/teste.csv"), ';', '"', 0);

            /* 
             * Dentro do while abaixo, temos a leitura da primeira linha do csv (títulos das colunas).
             * As demais linhas são lidas e incorporadas a tabela
             */
            while ((proximo = reader.readNext()) != null) {
                int i = 2;
                if (proximo != null) {
                    if (!primeiraLinha) {
                        adicionarAnos(proximo);
                        primeiraLinha = true;
                        continue;
                    }

                    Pais pais = new Pais();
                    pais.setId(proximo[0]);
                    pais.setNome(proximo[1]);

                    for (String nome : anos) {
                        pais.preencherCampoDado(nome, new Double(proximo[i]));
                        i++;
                    }
                    qtdPaises.put(pais.getId(), pais);
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(Arquivo.class.getName()).log(Level.SEVERE, null, ex);
        }
        return qtdPaises;
    }

    public List<String> obterPrimeiraLinha() {
        return anos;
    }

    public void adicionarAnos(String[] proximo) {
        for (String col : proximo) {
            if (!col.equals("ID") && !col.equals("NOME")) {
                anos.add(col);
            }
        }
    }
}
