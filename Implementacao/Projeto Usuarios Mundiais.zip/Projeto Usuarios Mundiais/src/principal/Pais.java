package principal;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Pais {

    private String id;
    private String nome;
    private Map<String, Double> dados;

    public Pais() {
        dados = new TreeMap();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Map<String, Double> getDados() {
        return dados;
    }

    public void preencherCampoDado(String anos, Double porc) {
        this.dados.put(anos, porc);
    }

    public double consultarDado(String anos) {
        return this.dados.get(anos);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Identificador (Id):");
        sb.append(this.id);
        sb.append(";");
        sb.append("Nome do Pais:");
        sb.append(this.nome);
        sb.append(";");

        for (Map.Entry<String, Double> entry : this.dados.entrySet()) {
            sb.append(entry.getKey());
            sb.append(":");
            sb.append(entry.getValue());
            sb.append(";");
        }

        return sb.toString();

    }

}
