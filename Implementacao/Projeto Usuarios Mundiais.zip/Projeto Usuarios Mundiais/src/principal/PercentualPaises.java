package principal;

import dados.Arquivo;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class PercentualPaises {

    private final Map<String, Pais> qtdPaises;
    private final Arquivo arq;
    public final List<String> periodo;

    public PercentualPaises() {
        arq = new Arquivo();
        qtdPaises = arq.lerArquivoCSV();
        periodo = arq.obterPrimeiraLinha();
    }

    public int contarPaises() {
        return this.qtdPaises.size();
    }

    public static void main(String args[]) {
        PercentualPaises exemplo = new PercentualPaises();
    }

    public Map<String, Pais> consultarPaises(String nomePais) {
        Map<String, Pais> paises = new TreeMap();
        for (Map.Entry<String, Pais> entry : this.qtdPaises.entrySet()) {
            String pais = entry.getValue().getNome().toLowerCase();
            if (pais.contains(nomePais)) {
                paises.put(entry.getKey(), entry.getValue());
            }
        }
        return paises;
    }

    public Pais selecionarPais(String id) {
        return qtdPaises.get(id);
    }

}
