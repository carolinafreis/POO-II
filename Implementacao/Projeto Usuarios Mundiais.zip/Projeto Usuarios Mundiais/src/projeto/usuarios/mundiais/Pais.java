/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto.usuarios.mundiais;

/**
 *
 * @author Carol
 */
public class Pais {
    
    private int idPais;
    private String nomePais;

    public int getIdPais() {
        return idPais;
    }

    public String getNomePais() {
        return nomePais;
    }

    public void setIdPais(int idPais) {
        this.idPais = idPais;
    }

    public void setNomePais(String nomePais) {
        this.nomePais = nomePais;
    }
    
    
    
}
