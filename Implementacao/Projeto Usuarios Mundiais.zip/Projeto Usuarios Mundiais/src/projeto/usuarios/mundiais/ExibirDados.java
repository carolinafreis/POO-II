/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto.usuarios.mundiais;

/**
 *
 * @author Carol
 */



public class ExibirDados {
    
    private int idExibir;
    private int ano;
    private float percentual;

    public int getIdExibir() {
        return idExibir;
    }

    public int getAno() {
        return ano;
    }

    public float getPercentual() {
        return percentual;
    }

    public void setIdExibir(int idExibir) {
        this.idExibir = idExibir;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public void setPercentual(float percentual) {
        this.percentual = percentual;
    }

    
    
    
}
