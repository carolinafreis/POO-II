
package projeto.usuarios.mundiais;

import com.opencsv.CSVReader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection; 

/**
 *
 * @author VictorHugo
 */
public class ConjuntoPaises {
    Collection<Pais> paises;

    public Collection<Pais> getPaises() { 
        return paises;
    }

    public void setPaises(Collection<Pais> paises) {
        this.paises = paises;
    }
    
    public ConjuntoPaises(){
	paises = new ArrayList<>();
    }


	public void loadLocal(String diretorio) throws IOException {
		String line = "";

		try (BufferedReader br = new BufferedReader(new FileReader(diretorio))) {

			while ((line = br.readLine()) != null) {

				String[] pais = line.split(";");


				Pais p = new Pais();
				p.setNome(pais[0]);
                                
//				System.out.println(p.getNome());

				ArrayList<String> percentual = new ArrayList<String>();
                                
                                int anoInicial = 2000;
                                for(int i = 1; i<=16; i++){
//					System.err.println(pais[i]);
					percentual.add(pais[i]);
                                        System.out.println(pais[i]);
                                        if (pais[i].equals("") || pais[i].equals("..") )
                                            p.mapaPercentuaisPorAno.put(anoInicial,0.0 );
                                        else
                                            p.mapaPercentuaisPorAno.put(anoInicial,Double.valueOf(pais[i]) );
                                        
                                        anoInicial++;
				}

				p.setPercentualUsuarios(percentual);

				paises.add(p);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
