
package projeto.usuarios.mundiais;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {

    public static void main(String[] args) {
    	String csvPath = "funcNv.csv";
        try {
            ConjuntoPaises p = new ConjuntoPaises();
            p.loadLocal(csvPath);
//            System.out.println("Resultado: " + p.paises.toString());
         
            for(Pais paises: p.paises){
            	System.out.print(paises.getNome());
            	System.out.println(paises.getPercentualUsuarios());
            }
           
        } catch (Exception ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
}
