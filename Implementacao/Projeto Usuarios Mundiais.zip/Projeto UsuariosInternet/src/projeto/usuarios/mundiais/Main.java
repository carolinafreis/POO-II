package projeto.usuarios.mundiais;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {

    private String csvPath = "funcNv.csv";
    private ConjuntoPaises p;

    public Main() {
        this.p = new ConjuntoPaises();
    }

    public static void main(String[] args) {
        Main main = new Main();
        ArrayList<Pais> paises = main.search();
                
         for (Pais pais : paises) {
                System.out.print(pais.getNome());
                System.out.println(pais.getPercentualUsuarios());
         }
    }

    public ArrayList search() {
        try {
            p.loadLocal(csvPath);
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        return (ArrayList) p.getPaises();
    }
}
