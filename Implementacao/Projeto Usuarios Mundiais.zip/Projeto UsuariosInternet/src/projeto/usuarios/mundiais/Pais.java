package projeto.usuarios.mundiais;

import java.util.ArrayList;

/**
 *
 * @author VictorHugo
 */
public class Pais {
	// Classe pra guardar os dados (armazena)
	private String idPais;
	private String nome;      
        
	//   private Arr percentualUsuarios[ = new String[16];
	private ArrayList<String> percentualUsuarios = new ArrayList<String>();



	public String getIdPais() {
		return idPais;
	}

	public void setIdPais(String idPais) {
		this.idPais = idPais;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	void setIdPais() {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}

	public ArrayList<String> getPercentualUsuarios() {
		return percentualUsuarios;
	}

	public void setPercentualUsuarios(ArrayList<String> percentualUsuarios) {
		this.percentualUsuarios = percentualUsuarios;
	}

	@Override
	public String toString() {
		return "idPais=" + idPais + ", nome=" + nome
				+ ", percentualUsuarios=" + percentualUsuarios;
	}
}
