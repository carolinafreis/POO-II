package projeto.usuarios.mundiais;

public class PercentualAno {

	private int ano;
	private double percentual;

	public PercentualAno(int ano, double percentual){
		this.ano = ano;
		this.percentual= percentual;
	}

	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	public double getPercentual() {
		return percentual;
	}
	public void setPercentual(double percentual) {
		this.percentual = percentual;
	}

	@Override
	public String toString() {
		return "PercentualAno [ano=" + ano + ", percentual=" + percentual + "]";
	}
	
	
}
